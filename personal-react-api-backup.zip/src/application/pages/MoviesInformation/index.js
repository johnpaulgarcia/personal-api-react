import MoviesInformation from './MoviesInformation';
import styles from './moviesinformation.css';
export default MoviesInformation;