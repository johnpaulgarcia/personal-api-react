import React from 'react';
const Loading  = () => {
    return(
        <img class="loading" src="https://gifimage.net/wp-content/uploads/2017/09/ajax-loading-gif-transparent-background-8.gif" />
    );
}
export default Loading;