import Loading from './Loading';
import styles from './loading.css';
export default Loading;