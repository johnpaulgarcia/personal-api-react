import Categories from './Categories';
import styles from './categories.css';
export default Categories;