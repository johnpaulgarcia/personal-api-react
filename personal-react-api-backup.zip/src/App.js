import React from 'react';
import Application from './application';

function App() {
  return (
    <Application />
  );
}

export default App;
