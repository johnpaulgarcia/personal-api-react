import React, { Component } from 'react';
import styles from './categories.css';
export default class Categories extends Component {
    render(){
        return(
            <div className="categories-sm">
                Categories
            </div>
        );
    }
}