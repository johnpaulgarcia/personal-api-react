import Assortment from './Assortment';
import './assortment.css';
export default Assortment;