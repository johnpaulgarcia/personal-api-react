import React, { Component } from 'react';
class Assortment extends Component {
    render(){
        return(
            <div class="assortment">
               Powered by TMDB API
            </div>
        );
    }
}

export default Assortment;