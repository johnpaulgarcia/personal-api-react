import Movies from './Movies';
import styles from './movies.css';
export default Movies;