import React from 'react';
import Home from './Home';
import styles from './home.css';
export default Home;