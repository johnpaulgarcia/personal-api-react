import GenreList from './GenreList';
import styles from './genrelist.css';
export default GenreList;