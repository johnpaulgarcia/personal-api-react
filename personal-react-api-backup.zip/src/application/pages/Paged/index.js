import Paged from './Paged';
import './paged.css';
export default Paged;