import React from 'react';
import Application from './pages';
export default Application;